# Project 1: Analysis of BPA Housing Data
# Venki Uddameri, Lamar University

# Set working directory
path <- "/media/vuddameri/EXTHD/R-Workshop/Project1"  # see forward slash
setwd(path)  # sets working directory
getwd()

# Read the file
fname <- 'BPA-Housing.csv'
a <- read.csv(fname,header=TRUE,skip=2)
head(a)

# Extract Total volume as a vector
vol <- a$Volume  # stores the column as a vector
class(vol)

# extract using rows and column index
totlist1990 <- a[1:12,"TotalListings"] # 1990 #Listings

# extract using subset
InvMed100K <- subset(a,MedPrice>100000,select=c(MedPrice,Inventory))

# make a pairs plot without Date, Month, Year variables removed
pairs(a[,c(-1,-8,-9)],panel=panel.smooth,
      main="Pairwise Explorations",col='blue')

# Variability of Median Sales Price across different Months
months <- c("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug",
            "Sep","Oct","Nov","Dec")
par(mgp=c(3,1,0))
boxplot((MedPrice/1000)~Month,data=a,names=months,outline=FALSE,
        ylab="Median Sale Price [1000 $]", las=2,
        main='Variability of Median Sale Price by Month')

avpricehist <- hist(a$AvPrice,breaks='sturges',
     xlab="Mean Sale Price ($)",
     ylab='Density', freq=FALSE,
     main="Variation of Mean Sale Price 1990-2022",
     col='blue')
rug(a$AvPrice,col='red')
box()
avpricehist

# Create a correlation Plot
library(corrplot)
a_cor <- cor(a[,c(-1,-8,-9)],method='spearman')
corrplot(a_cor,method="circle",
         type="lower",diag=FALSE)
title("Spearman Rank Correlations",cex.main=0.8)

library(vcd)
price <- a$AvPrice
length(price)
Years <- unique(a$Year)
pricemat <- matrix(price,nrow=length(Years),
                   ncol=length(months),byrow=TRUE,
                   dimnames= list(Years,months))
heatmap(pricemat,scale='none')
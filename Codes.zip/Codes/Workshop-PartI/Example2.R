# Example 2  - R Workshop
# Venki Uddameri, Lamar University

# Sequence of numbers examples

a <- c(1,2,3,4,pi)  # A vector example
length(a)

print(a[1]) # R uses 1 based index
print(a[3:length(a)])  # subset using indices
print(a[-1])  # Remove the first element and print
class(a)

b <- list("a","b",1,2,3, 4+3i)
length(b)
print(b[[2]])  # print 2nd element of the list
print(b[-3]) # remove 3rd element of the list
print(b[1:3]) # plot 1:3 elemnts of the list
class(b)

s <- "I love R"  #Note String is not a sequence
print(length(s))
print(s[2])


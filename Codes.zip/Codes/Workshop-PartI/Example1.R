# Example 1: Constants 
# This is a comment line
# Let us define an integer
a <- 2L # <- is an assignment operator; L implies integer
b <- pi  # pi is a floating point number
c <- "I love R"  # this is a character type data
d <- 3+4i # Complex number

# Let us print these values
print(list(a,b,c,d))

# check the data types
class(a)
class(b)
class(c)
class(d)